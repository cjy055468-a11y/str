#pragma once

// This makes sure we can't include components any other way than by including this file
#define TP_INTERNAL_COMPONENTS_GUARD

#include <Components/LocalAnimationComponent.h>
#include <Components/RemoteAnimationComponent.h>
#include <Components/EarlyAnimationBufferComponent.h>
#include <Components/ReplayedActionsDebugComponent.h>
#include <Components/FormIdComponent.h>
#include <Components/InterpolationComponent.h>
#include <Components/WaitingForAssignmentComponent.h>
#include <Components/LocalComponent.h>
#include <Components/RemoteComponent.h>
#include <Components/FaceGenComponent.h>
#include <Components/CacheComponent.h>
#include <Components/WaitingFor3D.h>
#include <Components/ActorValuesComponent.h>
#include <Components/ObjectComponent.h>
#include <Components/PlayerComponent.h>
#include <Components/CombatComponent.h>

#undef TP_INTERNAL_COMPONENTS_GUARD
