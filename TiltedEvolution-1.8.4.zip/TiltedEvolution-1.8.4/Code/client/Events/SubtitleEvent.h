#pragma once

struct SubtitleEvent
{
    SubtitleEvent(uint32_t aSpeakerID, String aText)
        : SpeakerID(aSpeakerID)
        , Text(aText)
    {
    }

    SubtitleEvent(uint32_t aSpeakerID, String aText, uint32_t aTopicFormID)
        : SpeakerID(aSpeakerID)
        , Text(aText)
        , TopicFormID(aTopicFormID)
    {
    }

    uint32_t SpeakerID{};
    String Text{};
    // This is only relevant to fallout 4
    uint32_t TopicFormID{};
    uint32_t SceneID{}; // Scene the line is spoken in, 0 for player dialogue menu lines and lines outside scenes
    uint32_t ScenePhase{}; // The scene's current phase when the line started
};
