#pragma once

struct PartyLeftEvent
{
};
