#pragma once

struct NiRTTI
{
};
