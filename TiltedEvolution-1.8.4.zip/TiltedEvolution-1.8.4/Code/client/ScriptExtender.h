#pragma once
// Utility to import the 3rd-party Script Extender made by Ian Patterson et al.
// Required for non-Creation Kit mods such as SkyUI
void LoadScriptExtender();

// Check if the SE is active
bool IsScriptExtenderLoaded();
